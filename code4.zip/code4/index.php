<?php 

require "./templates/header.php"

?>


<header id="top"class="header-1" >
       
        <div class="text-box">
    
            <h1> Welcome to Just Anime  <?php 
        if(isset($_SESSION['userUid'])){
    echo "{$_SESSION['userUid']}";
}
?>
</h1>
            
            <a href="index.php#About" class="hero-btn">Visit Us to know More</a>
        </div>
</header>
    

<section id="About" class="flex-columns">
        <div class="row">
            <div class="column">
                <div class="column-1">
                    <h2>About this Website</h2>
                    <p> Just Anime is my small website here on the net where I pour all of my thoughts regarding anime, manga and other things related to my otaku hobbies. You can find some awesome anime Wallpaper, Also you are welcome to upload your anime Wallpaper as well.</p>
                    
                </div>
            </div>
            <div class="column">
                <div class="column-2" id="btn">
                    
                    <a href="img/ab.gif"><img src="./img/satoi.gif" alt="Oreki"></a> 
                </div>
            </div>
            <div class="column">
                <div class="column-3">
                    <h3>DISCLAIMER:</h3>
                    <p>The images to be found in this website are owned by their respective owners unless otherwise stated. If ever the owner wanted their works to be removed from this site, please do contact the author so that he can comply with it immediately.
                    </p>
                    
                    
                </div>
            </div>
        </div>
    </section>
    <section id="Wallpaper" class="Gallery flex-grid spection-padding">
    <header class="section-header">
        <h2>Your Pic Upload here</h2>
        <?php  require "./includes/connect.inc.php"; ?>
        </header>
        <div class="rows">
<?php 
// 2. Query the DATABASE
// a. Declare the our SQL
$sql = "SELECT id, title, imageurl, comment, websiteurl, websitetitle,dt FROM post";

// b. Querying and Storing result
 $result =mysqli_query($conn,$sql);
?>
 <?php
  // 3.Data Structure & Creating the Loop
 if(mysqli_num_rows($result)<= 0){
  echo '0 results';
 
  
 }else{
    // success / Loop the data
    $output = "";
    while($row =mysqli_fetch_assoc($result)){
      // LOOP OPERATION
      $output .= '
      <div class="card border-0 mt-3" id=" '.$row['id'].' ">
        <img src= "'.$row['imageurl'].'" class="card-img-top post-image" alt="">
        <h5 class="card-title">'.$row['title'].' </h5>
        <p class="card-text">'.$row['dt'].' </p>

        </div>
       
        ';
   }
   echo $output;
  }
 ?>
   
        </div>
    </section>

    <section id="Myself" class="Social">
        <header class="section-header">
            <h2>Myself</h2>
            </header>
            <div class="Contact">
                <div class="C">
                    <div class="C-1">
                        <img src="img/ss.gif" alt="MyLogo">
                    </div>
                </div>
                <div class="C">
                    <div class="C-2">
                        <div class="form">
                            <h2>Contact Us</h2>  
                            <form action="sendmessage.php" method="post">

                            <input type="email" name="email" placeholder="Your Email" required>
                            <textarea rows="8" name="message" placeholder="Message" required></textarea>
                            <button type="submit" name="send" class=" hero-btn btn-outline">Sene me Message</button>
                        </form>
                        
                        <div class="Connect">
                            <a href="https://www.instagram.com/"><i class="fab fa-instagram fa-2x" ></i></a>
                            <a href="https://www.facebook.com/"><i class="fab fa-facebook fa-2x"></i></a>
                            <a href="https://twitter.com/home"><i class="fab fa-twitter fa-2x"></i></a>
                        </div>    
    
                        </div>
                        
                    </div>
                </div>
            </div>

    </section>
    <a href="index.php#top"><i class="far fa-arrow-alt-circle-up fa-2x" ></i></a>
    <?php
    require "./templates/footer.php";
    ?>                       
                

   

 
 
    
     
