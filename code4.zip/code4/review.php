<!-- HEADER.PHP -->
<?php 

  require "templates/header2.php"
?>
  <main class="container p-4 bg-light mt-3" style="width: 1000px">

 <?php
   // 1. Connection to the Database
   require "./includes/connect.inc.php";

   // 2. Query the DATABASE
   // a. Declare the our SQL
   $sql = "SELECT id, title, imageurl, comment, websiteurl, websitetitle, dt FROM post ORDER BY title;";
 
   // b. Querying and Storing result
   $result =mysqli_query($conn,$sql);

 ?>
 <!-- DYNAMIC  MESSAGE: ERROR & SUCCESS (DELETE REQUEST) -->
 <?php 

     // DYNAMIC MESSAGE FOR POST CREATION [CHALLENGE!] / UPDATE 
     if(isset($_GET['post']) == "success"){
      echo '<div class="alert alert-success" role="alert">
        Post created!
      </div>';  
    } else if(isset($_GET['edit']) == "success"){
      echo '<div class="alert alert-success" role="alert">
        Post edited!
      </div>'; 
    }
    // DYNAMIC ERROR/SUCCESS MESSAGES FOR DELETE
    if(isset($_GET['error'])){
      // (i) Internal server error 
      if ($_GET['error'] == "sqlerror") {
        $errorMsg = "An internal server error has occurred - please try again later";
      }

      // (ii) Dynamic Error Alert based on Variable Value 
      echo '<div class="alert alert-danger" role="alert">' . $errorMsg . '</div>';

    // (iii) Display SUCCESS message for correct login!
    } else if (isset($_GET['delete']) == "success"){
      echo '<div class="alert alert-success" role="alert">
        Post successfully deleted!
      </div>';    
    }
?>

<?php
  // 3.Data Structure & Creating the Loop
 if(mysqli_num_rows($result,) <= 0){
  echo '0 results';
 
  
 }else{
  // success / Loop the data
  $output = "";
  while($row =mysqli_fetch_assoc($result)){
    // LOOP OPERATION
    $output .= '
    <div class="card border-0 mt-3" id=" '.$row['id'].' ">
      <img src= "'.$row['imageurl'].'" class="card-img-top post-image" alt="">
      <div class="card-body">
        <h5 class="card-title">'.$row['title'].' </h5>
        <p class="card-text">'.$row['comment'].' </p>
        <p class="card-text">'.$row['dt'].' </p>
        <a href="'.$row['websiteurl'].'" class="btn btn-primary w-100" 
        target="_blank">'.$row['websitetitle'].'</a>';
      
    if(isset($_SESSION['userId'])){
  $output .= '
    <div class="admin-btn">
    <a href="editrivew.php?id='.$row['id'].'" class="btn btn-secondary mt-2">Edit</a>
    <a href="includes/deleterivew.inc.php?id='.$row['id'].'" class="btn btn-danger mt-2">Delete</a>
    </div>';
}
$output .= '
    </div>
    </div>';

 }
 echo $output;
}
 mysqli_close($conn);
?>
</main>


<!-- FOOTER.PHP -->
<?php 
  require "templates/footer.php"
?>