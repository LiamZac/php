<?php 
  require "templates/header.php"
?>

<div class="background"></div>
    <div class="card">
    <img class="logo" src="./img/justtv.svg"/>
    <form action="./includes/login.inc.php" class="login-form" method="POST">
    <div class="login-card">
    <h2>Create Account</h2>
      <h3>Enter your credentials</h3>
        <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="mailuid" placeholder="Email Address">
        <input type="password" class="form-control" id="password" name="pwd" placeholder="Password"></input>
        <a href="http:./signup.php"> Don't have an account? Create an account here.</a> <br>
        <button type="submit" class="btn " name="login-submit" style="background: #410099; margin-top:20px; color:whitesmoke;">Log In</button>
    </form>
    </div>


<?php
require "./templates/footer.php";
?>


 
