<?php 
//   (1) Start Session
session_start();
// (2) Check user clicked submit button from createpost form + user is logged in
if(isset($_POST['post-submit'])&& isset($_SESSION['userId'])){
// (3) Connect to database
require "./connect.inc.php";
// (4) store variable +escape string 
$title =mysqli_escape_string( $conn,$_POST["title"]);
$imageUrl =mysqli_escape_string($conn,$_POST["imageurl"]);
$comment =mysqli_escape_string($conn,$_POST["comment"]);
$websiteUrl =mysqli_escape_string($conn,$_POST["websiteurl"]);
$websiteTitle =mysqli_escape_string($conn,$_POST["websitetitle"]);
$DaTime =mysqli_escape_string($conn,$_POST["DT"]);



// (5) Validation    
    // 1. check for empty form feild 
    if(empty($title) || empty($imageUrl) || empty($comment) || empty($websiteUrl)|| empty($websiteTitle) || empty($DaTime)){
        header("Location: ../createrivew.php?error=emptyfeilds");
exit();
    }
// (6)    DATABASE QUERY :Save new post to the database post table = Prepare Stament 
// 1. Prepare Stament
$sql = "INSERT INTO post VALUE (NULL, ?, ?, ?, ?,?,?)";
$statement = mysqli_stmt_init($conn);
if(!mysqli_stmt_prepare($statement, $sql)){
    header("Location: ../createrivew.php?error=sqlerror");
    exit();
}

//    2.  bind the statement 
mysqli_stmt_bind_param($statement,"ssssss",$title,$imageUrl,$comment,$websiteUrl,$websiteTitle,$DaTime);
mysqli_stmt_execute($statement);
// Assume Success/ Redrict On Success   



header("Location: ../review.php?post=success"); 
exit();
    

}else{
    header("Location: ../review.php?error=forbidden");
    exit();
    
}