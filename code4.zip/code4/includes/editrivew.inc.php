<?php 
// 1. AUTHORISATION: BLOCK USERS WHO HAVENT SUBMITTED FORME CORRECTLY OR NOT LOGGED IN 
session_start();
// allow to test it 
if(isset($_POST["edit-submit"]) && isset($_SESSION['userId'])){
// 2. CONNECT TO DATABASE 
require "./connect.inc.php";
$id = mysqli_escape_string($conn,$_GET['id']);
$id = intval($id);
$title =mysqli_escape_string( $conn,$_POST["title"]);
$imageUrl =mysqli_escape_string($conn,$_POST["imageurl"]);
$comment =mysqli_escape_string($conn,$_POST["comment"]);
$websiteUrl =mysqli_escape_string($conn,$_POST["websiteurl"]);
$websiteTitle =mysqli_escape_string($conn,$_POST["websitetitle"]);
$DaTime =mysqli_escape_string($conn,$_POST["DT"]);

// 3. VALADITION TEST FOR EMPTY FIELDS
//    check for empty form feild 
if(empty($title) || empty($imageUrl)|| empty($comment)|| empty($websiteUrl)|| empty($websiteTitle)|| empty($DaTime)){
    header("Location:../editrivew.php?emptyfeilds&id=$id");
    exit();
}
// 4. PREPARED STATEMENT:UPDATE THE POST TABLE ROW BBY ID 
$sql = "UPDATE post SET title=?,imageurl=?,comment=?,websiteurl=?,websitetitle=?, DT=? WHERE id=?;";
$statement =mysqli_stmt_init($conn);
if(!mysqli_stmt_prepare($statement,$sql)){
    header("Location: ../editrivew.php?error=sqlerror&id=$id");
    exit();
}
// binding the data 
mysqli_stmt_bind_param($statement, "ssssssi",$title,$imageUrl,$comment ,$websiteUrl,
$websiteTitle,$DaTime,$id);
mysqli_stmt_execute($statement);
// 5. REDIRECT USER TO POSTS PAGE ON SUCCESS / REDIRECT ON ERROR TO  EDITPOST
    header("Location: ../review.php?id=$id&edit=Success");
    exit();

}else{
    header("Location: ../editrivew.php?error=forbidden");
    exit();
}

?>