<?php
session_start();
if(isset($_SESSION['userId'])&& $_GET['id']){
// Connect to Database
require "./connect.inc.php";
// store id & escape
// (conveert to srting )
$id = mysqli_real_escape_string($conn,$_GET['id']); 

// (convert back to interger that database accepts)
$id =intval($id);

// PREPARE BY STATEMENT
// (i). Placeholder Query
$sql = "DELETE FROM post WHERE id=?";

// (ii). Init our Statement
$statement = mysqli_stmt_init($conn);

// (iii). Run / Test placeholder query
if(!mysqli_stmt_prepare($statement, $sql)){
    header("Location: ../rivew.php?error=sqlerror&id=$id");
    exit();
}
// (iv). Bind data to sql query ("i" is integer)
mysqli_stmt_bind_param($statement, "i",$id);

// (v). Excute the Query 
mysqli_stmt_execute($statement);

// Redrict on success 
header("Location: ../review.php?delete=success&id=$id");
    exit();

}else{
    header("Location:../review.php?error=forbidden");
    exit();
}
?>