<?php
  // 1. Check user clicked submit button on Login Form
  if(isset($_POST['login-submit'])){

    // 2. Connect to database
    require './connect.inc.php';

    // 3. Collect & store the POST username + password in variables
    $mailuid = $_POST['mailuid'];
    $password = $_POST['pwd'];

    // 4. Check username and password fields are not blank
    if(empty($mailuid) || empty($password)){

      header("Location: ../login.php?loginerror=emptyfields"); 
      exit(); 
    
    } else {
     // SQL QUERY 1: FINDING USER TO PASS IN USERS
        //    1.Set our Query with PlaceHolders- ?
      $sql = "SELECT * FROM users WHERE uidUsers=? OR emailUsers=?"; 

        //    2. Initialising the prepare statement
        $statement = $conn->stmt_init();

  //    3. Prepare & send statement to database to check templet SQL      
        if(!$statement->prepare($sql)) {
                header("Location: ../login.php?loginerror=sqlerror"); 
                exit(); 
            } else {
        //    4.Bind statement with data

        $statement->bind_param("ss", $mailuid, $mailuid);

        //    5. Excute the sql with Data 
        $statement->execute();

        // 6. Return result & store variable
        $result = $statement->get_result();       

        // Test result for matching user 
       
        if($row = mysqli_fetch_assoc($result)){
          // This compares password passed in by user VS encrypted password in DB
          $pwdCheck = password_verify($password, $row['pwd']);

        // case 1: password is imcorrect
        if($pwdCheck == false){
            header("Location: ../login.php?loginerror=wrongpwd");
            exit(); 

          // (ii) User exists - Password match & init session
          } else if ($pwdCheck == true) {
          // USER AUTHENTICATION 
            session_start();
            // Add users data to $session = Logged In (id & username)
            $_SESSION['userId'] = $row['idUsers']; 
            // Adds the data from $row['uidUsers'] to session variable
            $_SESSION['userUid'] = $row['uidUsers']; 
            // REMINDER: idUsers = PRIMARY KEY / uidUsers = USERNAME
            header("Location: ../index.php?login=success");
            exit(); 
          
          // (iii). Catch all for unexpected error (very remote!)
          } else {
            header("Location: ../login.php?loginerror=wrongpwd");
            exit(); 
          }
        
        // (iv). Error if no user was found in DB
        } else {
          header("Location: ../login.php?loginerror=nouser");
          exit(); 
        }
      }
    }
  // 7. We have to close this off - it relates back to our SUBMIT button CHECK
  } else {
    // If users try to access this file DIRECTLY - it REDIRECTS to signup page 
    header("Location: ../signup.php?loginerror=forbidden");
    exit();
  }

?>