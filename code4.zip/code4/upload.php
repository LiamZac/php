<?php 
  require "templates/header.php"
?>
 <div class="container mt-5">
    <div class="text-center mb-4">
      <h2 class="display-4 mb-2">
        Image<span>Uploader</span>
        <svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" fill="currentColor" class="bi bi-cloud-arrow-up-fill mb-1" viewBox="0 0 16 16">
          <path d="M8 2a5.53 5.53 0 0 0-3.594 1.342c-.766.66-1.321 1.52-1.464 2.383C1.266 6.095 0 7.555 0 9.318 0 11.366 1.708 13 3.781 13h8.906C14.502 13 16 11.57 16 9.773c0-1.636-1.242-2.969-2.834-3.194C12.923 3.999 10.69 2 8 2zm2.354 5.146a.5.5 0 0 1-.708.708L8.5 6.707V10.5a.5.5 0 0 1-1 0V6.707L6.354 7.854a.5.5 0 1 1-.708-.708l2-2a.5.5 0 0 1 .708 0l2 2z"/>
        </svg>
      </h2>
      <p class="lead">Select image to upload:</p>
    </div>

    <div class="row justify-content-center">
      <div class="col-8">
        <!-- A. File Upload Form: START -->
        <form action="./upload.php" method="POST" enctype="multipart/form-data">
          <div class="input-group mb-3">     
            <!-- File Input -->
            <input type="file" class="form-control" id="inputGroupFile" name="fileToUpload">

            <!-- Submit Button -->
            <input type="submit" value="Upload" name="submit" class="btn btn-primary input-group-text"></input>
          </div>

        </form>
        <!-- File Upload Form: End-->
      </div>
    </div>
  </div>  
<?php 

  // REF: http://php.net/manual/en/features.file-upload.errors.php

  // 1. Access file in temporary storage 
        // i. declare the variables
        $directory ='uploads';
        $uploadOk = 1;
        $the_message = "";
        $the_message_ext ="";

        $phpFileUploadErrors = array(
          0 => 'There is no error, the file uploaded with success',
          1 => 'The uploaded file exceeds the upload_max_filesize directive in php.ini',
          2 => 'The uploaded file exceeds the MAX_FILE_SIZE directive that was specified in the HTML form',
          3 => 'The uploaded file was only partially uploaded',
          4 => 'No file was uploaded',
          6 => 'Missing a temporary folder',
          7 => 'Failed to write file to disk.',
          8 => 'A PHP extension stopped the file upload.',
        );

      if(isset($_POST["submit" ])){
        

        // ii. Save/ Upload data to variables
        $temp_name = $_FILES['fileToUpload']['tmp_name'];
        $target_file =$_FILES['fileToUpload']['name'];
        $imagesFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
        $my_url = $directory . DIRECTORY_SEPARATOR . $target_file;


        require "./includes/connect.inc.php";
        $sql =  "INSERT INTO images VALUES (NULL,'$target_file', '$target_file' )";
        $result = mysqli_query($conn,$sql);
    

        // iii. Validation / Custome Error Handling 
          //  (BONUS) Set additional error via php
          $the_error = $_FILES['fileToUpload']['error'];
          if($_FILES['fileToUpload']['error'] != 0){
            $the_message_ext = $phpFileUploadErrors[$the_error];
            $uploadOk = 0;
          }
          // (a.) Files Allready Exists
          if($the_message_ext == "" && file_exists($my_url)){
            $the_message_ext = "The Files Already Exists";
            $uploadOk = 0;
          }
          // (b.) Incorrect Files Extension
          if($the_message_ext == "" && $imagesFileType !="jpg" &&  $imagesFileType != "png" &&  $imagesFileType != "jpeg"&&  $imagesFileType != "gif"){
            $the_message_ext =" The File type is not Allowed, Please choose a .jpg, .jpeg, .gif or .png files";
            $uploadOk = 0;
          }
        // iv. Dynamic error/ Sucess Message
        if($uploadOk == 0){
          // Error STATE 
          $the_message = "<p>Sorry, your file was not uploaded. "."<strong>Eroor:</strong>".
          $the_message_ext  ."</p>";
        }else{
          // Success STATE
          if(move_uploaded_file($temp_name,$directory."/" .$target_file)){
            $the_message = '<p>File Uploaded Successfully.'.' Privew it:<a href=" '.$my_url .'" target="_blank"> '.$my_url.' </a></p>';
          }
        }
        }
        
?>
   <!-- Alert Message -->
   <?php 
          if($the_message ==""){
            echo null;
          }else if($uploadOk == 0){
            echo '<div class="alert alert-danger" role="alert"> '.$the_message.'</div>';
          }else{
            echo '<div class="alert alert-success" role="alert"> '.$the_message.' </div>';
          }
          ?>
<?php
require "./templates/footer.php";
?>
 

