<?php
if(isset($_POST['send'])){


require "./includes/connect.inc.php";
    // coonection to db

    // store submitted form data in variables

    $email = $_POST["email"];
    $message =$_POST['message'];

// 1. check for empty form feild 
     if(empty($email)|| empty($message)){
        // redirect 
        header("Location: index.php?error=emptyfeilds");
        exit();
    }
    // 1. Prepare Stament
$sql = "INSERT INTO Reply VALUES (NULL, ?, ?)"; 
$statement = mysqli_stmt_init($conn);

    if(!mysqli_stmt_prepare($statement, $sql)){
        header("Location: index.php?error=sqlerror");
        exit();
    }
    //    2.  bind the statement 
mysqli_stmt_bind_param($statement,"ss",$email,$message);
mysqli_stmt_execute($statement);

// Assume Success/ Redrict On Success   
header("Location: index.php?message=success"); 
exit();
    
    

}else{
        header("Location:index.php?errror=forbidden");
        exit();
    }
?>