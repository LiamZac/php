<?php 
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <!-- Bootstrap 5.0 CDN -->
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
  <!-- External CSS -->
  <!-- links -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Anton&family=Kaisei+Tokumin:wght@400;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
   <!-- links -->
   <link rel="stylesheet" href="./css/custom.css" />
   <link rel="stylesheet" href="./css/indexstyling.css" />



  

</head>
<body>
  <ul class="nav justify-content-center">
    <li class="nav-item">
      <a class="nav-link active" href="./index.php">Home</a>
    </li>
      <li class="nav-item">
        <a class="nav-link" href="./review.php">Review</a>
      </li>
      
      <?php 
            if(isset($_SESSION['userId'])){
              echo ' <li class="nav-item">
              <a class="nav-link" href="createrivew.php">Create Review</a>
            </li>';
            

            }
            if(!isset($_SESSION['userId'])){
              echo ' <li class="nav-item">
              <a class="nav-link active" href="./signup.php">Signup</a>
            </li>';
             }
            if(isset($_SESSION['userId'])){
              echo ' <li class="nav-item">
              <a class="nav-link active" href="./upload.php">Upload</a>
            </li>';
             }
             

            // <!-- login and logout  Fadded in and out -->
            if(isset($_SESSION['userId'])){
              echo ' <li class="nav-item">
              <form action="./includes/logout.inc.php" method="POST">
              <button type="submit" class="btn w-100" style="background-color:#410099;color:white" name="logout-submit">Logout</button>
              </form>';
            }
            if(!isset($_SESSION['userId'])){
              echo ' <li class="nav-item">
              <a class="nav-link active" href="./login.php">Login</a>
            </li>';
            }
           
          ?>  
      <!-- login and logout  Fadded in and out -->
    </ul>
  <!-- Dynamic Login Error Message -->
  <main class="container" style="text-align:center;">
    <?php
      // Check $_GET to see if we have any login error messages
      // NOTE: As with previous examples, will display appropriate error/success message in Bootstrap Alert 
      if(isset($_GET['loginerror'])){
        // (i) Empty fields in Login 
        if($_GET['loginerror'] == "emptyfields"){
          $errorMsg = "Please fill in all fields";

        // (ii) SQL Error
        } else if ($_GET['loginerror'] == "sqlerror"){
          $errorMsg = "Internal server error - please try again later";

        // (iii) Password does NOT match DB 
        } else if ($_GET['loginerror'] == "wrongpwd"){
          $errorMsg = "Wrong password";
          
        // (iv) uidUsers / emailUsers do not match
        } else if ($_GET['loginerror'] == "nouser"){
          $errorMsg = "The user does not exist";
        }
        // Display alert with dynamic error message
        echo '<div class="alert alert-danger" role="alert">'
          .$errorMsg.
        '</div>';

      // Display SUCCESS message for correct login!
      } else if (isset($_GET['login']) == "success"){
        echo '<div class="alert alert-success" role="alert">
          You have successfully logged in.
        </div>';    
      }
      
    ?>
  </main>
  <!-- Error Message from GET: END -->
    

   

     