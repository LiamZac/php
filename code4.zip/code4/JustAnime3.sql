-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Dec 01, 2022 at 01:16 AM
-- Server version: 5.7.34
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `JustAnime3`
--

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `imageurl` varchar(60) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `imageurl`, `name`) VALUES
(45, 'Grandeur.jpg', 'Grandeur.jpg'),
(46, 'HXH.jpg', 'HXH.jpg'),
(47, 'Gurenge.jpg', 'Gurenge.jpg'),
(48, 'demon.jpeg', 'demon.jpeg'),
(49, 'demon.jpeg', 'demon.jpeg'),
(50, 'JJK.jpg', 'JJK.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `title` tinytext,
  `imageurl` text,
  `comment` text,
  `websiteurl` text,
  `websitetitle` tinytext,
  `dt` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `title`, `imageurl`, `comment`, `websiteurl`, `websitetitle`, `dt`) VALUES
(43, 'One Punch Man', 'https://wallpapers.com/images/hd/one-punch-man-saitama-1ia57w4a00kt9jci.webp', 'One-Punch Man is a Japanese superhero manga series created by One. It tells the story of Saitama, a superhero who, because he can defeat any opponent with a single punch, grows bored from a lack of challenge. One wrote the original webcomic manga version in early 2009', 'https://wallpapers.com/wallpapers/one-punch-man-saitama-1ia57w4a00kt9jci.html', 'wallpapers.com', '2022-11-30 19:19:00'),
(44, 'Bleach', 'https://wallpapers.com/images/high/hd-anime-bleach-characters-3k49ghmz94wlvoss.webp', 'Ichigo Kurosaki never asked for the ability to see ghosts -- he was born with the gift. When his family is attacked by a Hollow -- a malevolent lost soul -- Ichigo becomes a Soul Reaper, dedicating his life to protecting the innocent and helping the tortured spirits themselves find peace.', 'https://wallpapers.com/wallpapers/hd-anime-bleach-characters-3k49ghmz94wlvoss.html', 'wallpapers.com', '2022-11-30 19:20:00'),
(45, 'Jujutsu Kaisen', 'https://wallpapers.com/images/hd/cute-first-years-jujutsu-kaisen-y25dcij0q6yw25oj.webp', 'Jujutsu Kaisen is a Japanese manga series written and illustrated by Gege Akutami. It has been serialized in Shueisha\\\'s shōnen manga magazine Weekly Shōnen Jump since March 2018, with its chapters collected and published in 20 tankōbon volumes as of August 2022.', 'https://wallpapers.com/wallpapers/cute-first-years-jujutsu-kaisen-y25dcij0q6yw25oj.html', 'wallpapers.com', '2022-11-30 19:21:00'),
(46, 'Demon Slayer', 'https://wallpapercave.com/uwp/uwp1868516.jpeg', 'Demon Slayer: Kimetsu no Yaiba is a Japanese manga series written and illustrated by Koyoharu Gotouge. It follows teenage Tanjiro Kamado, who strives to become a demon slayer after his family was slaughtered and his younger sister, Nezuko, turned into a demon', 'https://wallpapercave.com/w/uwp1868516', 'wallpapercave.com', '2022-11-30 19:21:00'),
(47, 'Naruto', 'https://wallpapercave.com/wp/wp10407580.jpg', 'Naruto is a Japanese manga series written and illustrated by Masashi Kishimoto. It tells the story of Naruto Uzumaki, a young ninja who seeks recognition from his peers and dreams of becoming the Hokage, the leader of his village.', 'https://wallpapercave.com/w/wp10407580', 'wallpapers.com', '2022-11-30 19:22:00'),
(48, 'Tokyo Ghoul', 'https://wallpapers.com/images/hd/minimalist-kaneki-ken-tokyo-ghoul-dnxi3ayx3e6jfyan.webp', 'Tokyo Ghoul is a Japanese dark fantasy manga series written and illustrated by Sui Ishida. It was serialized in Shueisha\\\'s seinen manga magazine Weekly Young Jump between September 2011 and September 2014, and was collected in fourteen tankōbon volumes', 'https://wallpapers.com/wallpapers/minimalist-kaneki-ken-tokyo-ghoul-dnxi3ayx3e6jfyan.html', 'wallpapers.com', '2022-11-30 19:23:00'),
(49, 'Black Clover', 'https://wallpapercave.com/uwp/uwp703530.jpeg', 'Black Clover is a Japanese manga series written and illustrated by Yūki Tabata. It has been serialized in Shueisha\\\\\\\\\\\\\\\'s shōnen manga magazine Weekly Shōnen Jump since February 2015, with its chapters collected in 33 tankōbon volumes as of November 2022. The story follows Asta, a young boy born without any magic power.', 'https://wallpapercave.com/w/uwp703530', 'wallpapercave.com', '2022-11-30 19:23:00'),
(50, 'Code Geass', 'https://wallpapers.com/images/hd/lelouch-lamperouge-code-geass-dbzxa31vyp151bjm.webp', 'The Holy Empire of Britannia conquered the country known as Japan and now call it Area 11. Its residents lost their rights to self-govern and are now called Elevens. The Empire uses powerfully destructive robotic weapons called Knightmares to ensure control, but someone is about to stand up against it. Lelouch, the black prince, has endless ambition and uses the power of the Geass to build a world based on his ideals. Suzaku Kururugi, the white knight, aspires to justice and strives to live an honest and fair life. This is an English dub version of the Japanese cartoon.', 'https://wallpapers.com/wallpapers/lelouch-lamperouge-code-geass-dbzxa31vyp151bjm.html', 'wallpapers.com', '2022-11-30 19:24:00'),
(51, 'Jujutsu Kaisen', 'https://ichef.bbci.co.uk/news/976/cpsprodpb/F382/production/_123883326_852a3a31-69d7-4849-81c7-8087bf630251.jpg', 'Yuji Itadori, a kind-hearted teenager, joins his school\\\\\\\'s Occult Club for fun, but discovers that its members are actual sorcerers who can manipulate the energy between beings for their own use. He hears about a cursed talisman - the finger of Sukuna, a demon - and its being targeted by other cursed beings.', 'https://www.crunchyroll.com/series/GRDV0019R/jujutsu-kaisen', 'crunchyroll.com', '2022-11-30 19:25:00'),
(52, 'My Hero Academia', 'https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/f0dfabec20d9f3ce33add1a92d381c70.jpeg', 'In a world where those with powers are known as \\\\\\\\\\\\\\\"Quirks,\\\\\\\\\\\\\\\" Izuku Midoriya has aspirations to one day become a hero but there\\\\\\\\\\\\\\\'s a catch -- he isn\\\\\\\\\\\\\\\'t a Quirk. After a tragic accident involving his friend Katuski Bakugo; Midoriya is the only one to have stepped forward to help protect Bakugo from a villain, because of his acts, he is given a gift by the world\\\\\\\\\\\\\\\'s greatest hero, All Might. Now, Midoriya attends U.A. School--a school that cultivates the next generation of superheroes.', 'https://www.funimation.com/shows/my-hero-academia/', 'funimation.com', '2022-11-30 19:26:00'),
(53, 'The God of High School', 'https://www.crunchyroll.com/imgsrv/display/thumbnail/1200x675/catalog/crunchyroll/f5507ec17b372d049a7d7d3e0634c31f.jpeg', 'The action anime follows a high school student Jin Mori and his friends as they compete in an epic tournament in which they borrow the power directly from the gods. But not only that, along the way they uncover a mysterious organization who will grant any wish to the tournament\\\\\\\'s winner', 'https://www.crunchyroll.com/series/GRVD0ZDQR/the-god-of-high-school', 'crunchyroll.com', '2022-11-30 19:26:00'),
(55, 'shoyo', 'https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1674&q=80', 'anime', 'https://unsplash.com/photos/qTlbO6mkQH0', 'Unsplash', '2022-12-01 11:43:00');

-- --------------------------------------------------------

--
-- Table structure for table `Reply`
--

CREATE TABLE `Reply` (
  `id` int(11) NOT NULL,
  `Uemail` varchar(255) DEFAULT NULL,
  `Rmessage` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Reply`
--

INSERT INTO `Reply` (`id`, `Uemail`, `Rmessage`) VALUES
(1, 'tenzee.theo@gmail.com', 'ok '),
(2, 'tibettenzee@gmail.com', 'Need More Anime Pictures ');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `idUsers` int(11) NOT NULL,
  `uidUsers` tinytext,
  `emailUsers` tinytext,
  `pwd` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`idUsers`, `uidUsers`, `emailUsers`, `pwd`) VALUES
(2, 'tenten', 'ten@ten.com', '$2y$10$RdIDXj6OfH9VmEOKAmaQ0e1yn8ifNIRisKZis2AeU76/AMg3LQJA6'),
(21, 'tintin', 'tin@tin.com', '$2y$10$8wAZtaHZHR4hO0.qh9lh6eP86KsN3yBgnOI3r84NEt2ZXwrJ2mRRO'),
(22, 'bob', 'Bob@john.com', '$2y$10$JinLqOyHudHHOjj7XY0JhO7mSSxKXXr0PKeRsyl5W/Ki1g/g9DmJi'),
(23, 'Alex', 'alex@alex.com', '$2y$10$i/6HuS0J2CpGuQlckR5a4OIjSZkj9bQ4XB/hjeKgrx3Xj.cVuIBRW');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `images`
--
ALTER TABLE `images`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Reply`
--
ALTER TABLE `Reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`idUsers`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `images`
--
ALTER TABLE `images`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `Reply`
--
ALTER TABLE `Reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `idUsers` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
